"""
Vinyl Collector — macOS · Windows · Web
Ejecutar: python main.py
"""
import sys
import flet as ft
import theme as th
from models import Vinyl, Conversation


async def main(page: ft.Page):
    # En Pyodide (GitHub Pages) instalar dependencias vía micropip antes de importar
    if sys.platform == "emscripten":
        import micropip
        await micropip.install("supabase==2.15.0")

    import database as db
    page.title      = "Vinyl Collector"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor    = th.BG
    page.padding    = 0
    page.window.width  = 800
    page.window.height = 600
    # Validar plataforma
    is_desktop = page.platform in (ft.PagePlatform.MACOS, ft.PagePlatform.WINDOWS)
    if page.platform == ft.PagePlatform.WINDOWS:
        print("Ejecutando en Windows")
    elif page.platform == ft.PagePlatform.MACOS:
        print("Ejecutando en macOS")
    elif page.platform == ft.PagePlatform.ANDROID:
        print("Ejecutando en Android")
        page.window.width  = 430
        page.window.height = 820



    # ── Init DB ───────────────────────────────────────────────────────────────
    db.init_db()

    state = {
        "user_id":   "",
        "user_name": "",
        "tab":       0,
    }

    def uid():   return state["user_id"]
    def uname(): return state["user_name"]

    # ── Área de contenido central ─────────────────────────────────────────────
    # La app vive completamente en este contenedor
    body = ft.Container(expand=True, bgcolor=th.BG)

    def set_body(control):
        body.content = control
        page.update()

    # ── Navegación — Rail (desktop) o Bar (mobile) ────────────────────────────
    _NAV_DESTINATIONS_BAR = [
        ft.NavigationBarDestination(
            icon=ft.Icons.ALBUM_OUTLINED,
            selected_icon=ft.Icons.ALBUM,
            label="Mi Colección",
        ),
        ft.NavigationBarDestination(
            icon=ft.Icons.STOREFRONT_OUTLINED,
            selected_icon=ft.Icons.STOREFRONT,
            label="Marketplace",
        ),
        ft.NavigationBarDestination(
            icon=ft.Icons.CHAT_BUBBLE_OUTLINE,
            selected_icon=ft.Icons.CHAT_BUBBLE,
            label="Mensajes",
        ),
        ft.NavigationBarDestination(
            icon=ft.Icons.PERSON_OUTLINE,
            selected_icon=ft.Icons.PERSON,
            label="Perfil",
        ),
    ]

    _NAV_DESTINATIONS_RAIL = [
        ft.NavigationRailDestination(
            icon=ft.Icons.ALBUM_OUTLINED,
            selected_icon=ft.Icons.ALBUM,
            label="Mi Colección",
        ),
        ft.NavigationRailDestination(
            icon=ft.Icons.STOREFRONT_OUTLINED,
            selected_icon=ft.Icons.STOREFRONT,
            label="Marketplace",
        ),
        ft.NavigationRailDestination(
            icon=ft.Icons.CHAT_BUBBLE_OUTLINE,
            selected_icon=ft.Icons.CHAT_BUBBLE,
            label="Mensajes",
        ),
        ft.NavigationRailDestination(
            icon=ft.Icons.PERSON_OUTLINE,
            selected_icon=ft.Icons.PERSON,
            label="Perfil",
        ),
    ]

    if is_desktop:
        nav = ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            bgcolor=th.SURFACE,
            indicator_color=ft.Colors.with_opacity(0.15, th.PRIMARY),
            min_width=80,
            min_extended_width=180,
            leading=ft.Container(
                padding=ft.padding.symmetric(vertical=16),
                content=ft.Icon(ft.Icons.ALBUM, color=th.PRIMARY, size=32),
            ),
            on_change=lambda e: show_tab(e.control.selected_index),
            destinations=_NAV_DESTINATIONS_RAIL,
        )
        shell = ft.Row(
            expand=True,
            spacing=0,
            controls=[
                nav,
                ft.VerticalDivider(width=1, color=th.DIVIDER),
                ft.Column(expand=True, spacing=0, controls=[body]),
            ],
        )
    else:
        nav = ft.NavigationBar(
            bgcolor=th.SURFACE,
            indicator_color=ft.Colors.with_opacity(0.15, th.PRIMARY),
            selected_index=0,
            on_change=lambda e: show_tab(e.control.selected_index),
            destinations=_NAV_DESTINATIONS_BAR,
        )
        shell = ft.Column(
            expand=True,
            spacing=0,
            controls=[body, nav],
        )

    # ── Pila de navegación manual (para sub-pantallas) ────────────────────────
    # Cada sub-pantalla se apila sobre el shell
    nav_stack: list[ft.Control] = []

    def push_screen(control):
        """Apila una pantalla encima del shell."""
        nav_stack.append(control)
        page.controls.clear()
        page.controls.append(control)
        page.update()

    def pop_screen():
        """Vuelve a la pantalla anterior."""
        if nav_stack:
            nav_stack.pop()
        if nav_stack:
            page.controls.clear()
            page.controls.append(nav_stack[-1])
        else:
            # Volver al shell principal
            page.controls.clear()
            page.controls.append(shell)
        page.update()

    def show_shell():
        nav_stack.clear()
        page.controls.clear()
        page.controls.append(shell)
        page.update()

    # ── Tabs principales ──────────────────────────────────────────────────────
    def show_tab(tab: int):
        state["tab"] = tab
        nav.selected_index = tab
        show_shell()
        if tab == 0:   set_body(build_home())
        elif tab == 1: set_body(build_marketplace())
        elif tab == 2: set_body(build_inbox())
        else:          set_body(build_profile())
        page.update()

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 0 — MI COLECCIÓN
    # ══════════════════════════════════════════════════════════════════════════
    def build_home():
        vinyls = db.get_my_vinyls(uid())

        grid = ft.GridView(
            expand=True,
            runs_count=0 if is_desktop else 2,
            max_extent=240 if is_desktop else 200,
            child_aspect_ratio=0.62,
            spacing=16 if is_desktop else 12,
            run_spacing=16 if is_desktop else 12,
            padding=24 if is_desktop else 16,
        )

        if not vinyls:
            grid.controls.append(ft.Container(
                expand=True,
                alignment=ft.Alignment.CENTER,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=14,
                    controls=[
                        ft.Icon(ft.Icons.ALBUM_OUTLINED, size=80,
                                color=ft.Colors.with_opacity(0.3, th.PRIMARY)),
                        ft.Text("Tu colección está vacía", size=20,
                                weight=ft.FontWeight.BOLD, color=th.ON_BG),
                        ft.Text("Agrega tu primer vinilo",
                                size=14, color=th.ON_SURFACE),
                        ft.ElevatedButton(
                            "Agregar Vinilo", icon=ft.Icons.ADD,
                            bgcolor=th.PRIMARY, color="white",
                            on_click=lambda _: show_add(None),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=12)),
                        ),
                    ],
                ),
            ))
        else:
            for v in vinyls:
                grid.controls.append(
                    make_vinyl_card(v, lambda _, vinyl=v: show_detail(vinyl))
                )

        header_pad = ft.Padding.only(
            left=28 if is_desktop else 20,
            top=20 if is_desktop else 12,
            right=20 if is_desktop else 12,
            bottom=12 if is_desktop else 8,
        )
        return ft.Column(
            expand=True, spacing=0,
            controls=[
                ft.Container(
                    bgcolor=th.BG,
                    padding=header_pad,
                    content=ft.Row(
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            ft.Column(spacing=2, controls=[
                                ft.Text("Mi Colección",
                                        size=28 if is_desktop else 22,
                                        weight=ft.FontWeight.BOLD,
                                        color=th.ON_BG),
                                ft.Text(
                                    f"{len(vinyls)} vinilo"
                                    f"{'s' if len(vinyls) != 1 else ''}",
                                    size=13 if is_desktop else 12,
                                    color=th.ON_SURFACE),
                            ]),
                            ft.ElevatedButton(
                                "Agregar Vinilo",
                                icon=ft.Icons.ADD,
                                bgcolor=th.PRIMARY,
                                color="white",
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10)),
                                on_click=lambda _: show_add(None),
                            ) if is_desktop else ft.FloatingActionButton(
                                icon=ft.Icons.ADD,
                                bgcolor=th.PRIMARY,
                                mini=True,
                                on_click=lambda _: show_add(None),
                            ),
                        ],
                    ),
                ),
                ft.Divider(height=1, color=th.DIVIDER),
                grid,
            ],
        )

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 1 — MARKETPLACE
    # ══════════════════════════════════════════════════════════════════════════
    def build_marketplace():
        all_v = db.get_marketplace_vinyls(uid())
        search_val = [""]
        tab_idx = [0]

        grid = ft.GridView(
            expand=True,
            runs_count=0 if is_desktop else 2,
            max_extent=240 if is_desktop else 200,
            child_aspect_ratio=0.58,
            spacing=16 if is_desktop else 12,
            run_spacing=16 if is_desktop else 12,
            padding=24 if is_desktop else 16,
        )

        def refresh_grid():
            q   = search_val[0].lower()
            idx = tab_idx[0]
            filtered = [
                v for v in all_v
                if (idx == 0 or (idx == 1 and v.is_for_sale) or
                    (idx == 2 and v.is_for_trade))
                and (not q or q in v.title.lower() or
                     q in v.artist.lower() or q in v.genre.lower())
            ]
            grid.controls.clear()
            if not filtered:
                grid.controls.append(ft.Container(
                    alignment=ft.Alignment.CENTER,
                    content=ft.Text("Sin resultados", color=th.ON_SURFACE),
                ))
            else:
                for v in filtered:
                    grid.controls.append(
                        make_vinyl_card(
                            v,
                            lambda _, vinyl=v: show_detail(vinyl),
                            show_owner=True,
                        )
                    )
            page.update()

        refresh_grid()

        tab_row = ft.Ref[ft.Row]()

        def select_tab(i: int):
            tab_idx.__setitem__(0, i)
            # Rebuild tab row styling
            for j, c in enumerate(tab_row.current.controls):
                c.border = ft.border.only(
                    bottom=ft.BorderSide(2 if j == i else 0, th.PRIMARY))
                c.content.color  = th.PRIMARY if j == i else th.ON_SURFACE
                c.content.weight = (ft.FontWeight.BOLD if j == i
                                    else ft.FontWeight.NORMAL)
            refresh_grid()

        def _tab_btn(label: str, idx: int) -> ft.Container:
            sel = idx == 0
            return ft.Container(
                expand=True,
                padding=ft.padding.symmetric(horizontal=8, vertical=10),
                border=ft.border.only(
                    bottom=ft.BorderSide(2 if sel else 0, th.PRIMARY)),
                on_click=lambda _, i=idx: select_tab(i),
                content=ft.Text(
                    label, size=13, text_align=ft.TextAlign.CENTER,
                    color=th.PRIMARY if sel else th.ON_SURFACE,
                    weight=ft.FontWeight.BOLD if sel else ft.FontWeight.NORMAL,
                ),
            )

        tabs = ft.Row(
            ref=tab_row,
            spacing=0,
            controls=[
                _tab_btn("Todo", 0),
                _tab_btn("En Venta", 1),
                _tab_btn("Intercambio", 2),
            ],
        )

        search = ft.TextField(
            hint_text="Buscar...",
            prefix_icon=ft.Icons.SEARCH,
            bgcolor=th.SURFACE_VAR,
            border_color=th.DIVIDER,
            focused_border_color=th.PRIMARY,
            color=th.ON_BG,
            hint_style=ft.TextStyle(color="#666666"),
            border_radius=12,
            on_change=lambda e: (
                search_val.__setitem__(0, e.control.value),
                refresh_grid(),
            ),
        )

        return ft.Column(
            expand=True, spacing=0,
            controls=[
                ft.Container(
                    bgcolor=th.BG,
                    padding=ft.Padding.only(
                        left=28 if is_desktop else 16,
                        top=20 if is_desktop else 12,
                        right=28 if is_desktop else 16,
                        bottom=4,
                    ),
                    content=ft.Column(spacing=10 if is_desktop else 8, controls=[
                        ft.Text("Marketplace",
                                size=28 if is_desktop else 22,
                                weight=ft.FontWeight.BOLD, color=th.ON_BG),
                        search,
                        tabs,
                    ]),
                ),
                grid,
            ],
        )

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 2 — MENSAJES
    # ══════════════════════════════════════════════════════════════════════════
    def build_inbox():
        convs = db.get_conversations(uid())
        items = []

        for conv in convs:
            last   = conv.last_message
            unread = conv.unread_count
            items.append(ft.Container(
                bgcolor=th.BG,
                padding=ft.padding.symmetric(horizontal=16, vertical=12),
                on_click=lambda _, c=conv: (
                    db.mark_as_read(uid(), c.other_user_id),
                    show_conversation(
                        c.other_user_id, c.other_user_name,
                        c.vinyl_id, c.vinyl_title,
                    ),
                ),
                ink=True,
                content=ft.Row(spacing=12, controls=[
                    ft.Stack(width=52, height=52, controls=[
                        ft.CircleAvatar(
                            content=ft.Text(
                                conv.other_user_name[0].upper(),
                                weight=ft.FontWeight.BOLD, color=th.PRIMARY,
                            ),
                            bgcolor=ft.Colors.with_opacity(0.2, th.PRIMARY),
                            radius=26,
                        ),
                        *(
                            [ft.Container(width=13, height=13,
                                          border_radius=7,
                                          bgcolor=th.PRIMARY,
                                          right=0, top=0)]
                            if unread > 0 else []
                        ),
                    ]),
                    ft.Column(expand=True, spacing=2, controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text(conv.other_user_name, size=15,
                                        weight=ft.FontWeight.BOLD
                                        if unread else ft.FontWeight.NORMAL,
                                        color=th.ON_BG),
                                ft.Text(
                                    last.timestamp[11:16] if last else "",
                                    size=11, color=th.ON_SURFACE,
                                ),
                            ],
                        ),
                        *(
                            [ft.Text(f"📀 {conv.vinyl_title}", size=11,
                                     color=th.PRIMARY)]
                            if conv.vinyl_title else []
                        ),
                        ft.Text(last.content if last else "", size=13,
                                color=th.ON_BG if unread else th.ON_SURFACE,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS),
                    ]),
                ]),
            ))
            items.append(ft.Divider(height=1, color=th.DIVIDER))

        if not items:
            items = [ft.Container(
                expand=True,
                alignment=ft.Alignment.CENTER,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=12,
                    controls=[
                        ft.Icon(ft.Icons.MARK_CHAT_UNREAD_OUTLINED,
                                size=72,
                                color=ft.Colors.with_opacity(0.3, th.ON_SURFACE)),
                        ft.Text("Sin mensajes aún", size=18,
                                weight=ft.FontWeight.BOLD, color=th.ON_BG),
                        ft.Text("Contacta a un coleccionista\ndesde el Marketplace",
                                size=13, color=th.ON_SURFACE,
                                text_align=ft.TextAlign.CENTER),
                    ],
                ),
            )]

        list_view = ft.ListView(expand=True, controls=items)

        if is_desktop:
            return ft.Column(
                expand=True, spacing=0,
                controls=[
                    ft.Container(
                        bgcolor=th.BG,
                        padding=ft.Padding.only(left=28, top=20, right=28, bottom=12),
                        content=ft.Text("Mensajes", size=28,
                                        weight=ft.FontWeight.BOLD, color=th.ON_BG),
                    ),
                    ft.Divider(height=1, color=th.DIVIDER),
                    ft.Row(
                        expand=True,
                        spacing=0,
                        controls=[
                            ft.Container(
                                width=320,
                                content=list_view,
                                border=ft.border.only(
                                    right=ft.BorderSide(1, th.DIVIDER)),
                            ),
                            ft.Container(
                                expand=True,
                                alignment=ft.Alignment.CENTER,
                                content=ft.Column(
                                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    spacing=10,
                                    controls=[
                                        ft.Icon(ft.Icons.CHAT_BUBBLE_OUTLINE,
                                                size=56,
                                                color=ft.Colors.with_opacity(
                                                    0.2, th.ON_SURFACE)),
                                        ft.Text("Selecciona una conversación",
                                                size=15, color=th.ON_SURFACE),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            )

        return ft.Column(
            expand=True, spacing=0,
            controls=[
                ft.Container(
                    bgcolor=th.BG,
                    padding=ft.Padding.only(left=20, top=12, right=16, bottom=12),
                    content=ft.Text("Mensajes", size=22,
                                    weight=ft.FontWeight.BOLD, color=th.ON_BG),
                ),
                ft.Divider(height=1, color=th.DIVIDER),
                list_view,
            ],
        )

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 3 — PERFIL
    # ══════════════════════════════════════════════════════════════════════════
    def build_profile():
        vinyls    = db.get_my_vinyls(uid())
        for_sale  = sum(1 for v in vinyls if v.is_for_sale)
        for_trade = sum(1 for v in vinyls if v.is_for_trade)

        def stat(label, value, icon, color=th.PRIMARY):
            return ft.Container(
                expand=True,
                padding=ft.padding.symmetric(horizontal=8, vertical=14),
                border_radius=12, bgcolor=th.SURFACE_VAR,
                border=ft.border.all(1, th.DIVIDER),
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=4,
                    controls=[
                        ft.Icon(icon, color=color, size=22),
                        ft.Text(value, size=20,
                                weight=ft.FontWeight.BOLD, color=color),
                        ft.Text(label, size=11, color=th.ON_SURFACE),
                    ],
                ),
            )

        profile_content = ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=16,
                    controls=[
                        ft.CircleAvatar(
                            content=ft.Text(
                                uname()[0].upper() if uname() else "?",
                                size=40, weight=ft.FontWeight.BOLD,
                                color=th.PRIMARY),
                            bgcolor=ft.Colors.with_opacity(0.2, th.PRIMARY),
                            radius=50),
                        ft.Text(uname(), size=22,
                                weight=ft.FontWeight.BOLD, color=th.ON_BG),
                        ft.Text("Coleccionista de Vinilos",
                                size=14, color=th.ON_SURFACE),
                        ft.Row(spacing=8, controls=[
                            stat("Total",      str(len(vinyls)), ft.Icons.ALBUM),
                            stat("En Venta",   str(for_sale),
                                 ft.Icons.SELL, "#4CAF50"),
                            stat("Para Cambio", str(for_trade),
                                 ft.Icons.SWAP_HORIZ, "#29B6F6"),
                        ]),
                        ft.Divider(color=th.DIVIDER),
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.INFO_OUTLINE,
                                            color=th.PRIMARY),
                            title=ft.Text("Vinyl Collector v1.0",
                                          color=th.ON_BG),
                            subtitle=ft.Text("Hecho con Flet + Python",
                                             color=th.ON_SURFACE),
                        ),
                        ft.OutlinedButton(
                            "Cerrar Sesión",
                            icon=ft.Icons.LOGOUT,
                            expand=not is_desktop,
                            style=ft.ButtonStyle(
                                color="#EF5350",
                                shape=ft.RoundedRectangleBorder(radius=12),
                                side=ft.BorderSide(color="#EF5350", width=1.5),
                            ),
                            on_click=lambda _: _logout(),
                        ),
                    ],
                )

        if is_desktop:
            return ft.Column(
                scroll=ft.ScrollMode.AUTO, expand=True,
                controls=[
                    ft.Container(
                        expand=True,
                        alignment=ft.Alignment.TOP_CENTER,
                        padding=ft.padding.symmetric(vertical=40, horizontal=0),
                        content=ft.Container(
                            width=480,
                            content=profile_content,
                        ),
                    ),
                ],
            )

        return ft.Column(
            scroll=ft.ScrollMode.AUTO, expand=True,
            controls=[ft.Container(padding=20, content=profile_content)],
        )

    # ══════════════════════════════════════════════════════════════════════════
    # SUB-PANTALLAS (se apilan encima del shell)
    # ══════════════════════════════════════════════════════════════════════════
    def show_add(existing: Vinyl | None):
        from views.add_vinyl_view import add_vinyl_view
        screen = add_vinyl_view(
            page, uid(), uname(), existing,
            on_saved=lambda: (pop_screen(), show_tab(state["tab"])),
            on_back=pop_screen,
        )
        push_screen(screen)

    def show_detail(vinyl: Vinyl):
        from views.vinyl_detail_view import vinyl_detail_view
        screen = vinyl_detail_view(
            page, vinyl, uid(), uname(),
            is_owner=vinyl.owner_id == uid(),
            on_back=pop_screen,
            on_edit=lambda v: (pop_screen(), show_add(v)),
            on_contact=lambda v, msg: show_conversation(
                v.owner_id, v.owner_name, v.id, v.title, msg),
            on_delete=lambda: (pop_screen(), show_tab(0)),
        )
        push_screen(screen)

    def show_conversation(other_id, other_name,
                          vinyl_id=None, vinyl_title=None,
                          initial_msg=None):
        from views.conversation_view import conversation_view
        screen = conversation_view(
            page, uid(), uname(),
            other_id, other_name,
            vinyl_id, vinyl_title, initial_msg,
            on_back=lambda: (pop_screen(),
                             show_tab(2)),
        )
        push_screen(screen)

    # ══════════════════════════════════════════════════════════════════════════
    # AUTH (Login / Registro)
    # ══════════════════════════════════════════════════════════════════════════
    def show_auth():
        from views.auth_view import auth_view
        auth_view(page, on_success=_on_login_success)

    def _on_login_success(user_id: str, user_name: str):
        state["user_id"]   = user_id
        state["user_name"] = user_name
        show_shell()
        show_tab(0)

    def _logout():
        state["user_id"]   = ""
        state["user_name"] = ""
        show_auth()

    # ══════════════════════════════════════════════════════════════════════════
    # VINYL CARD (widget compartido)
    # ══════════════════════════════════════════════════════════════════════════
    def make_vinyl_card(vinyl: Vinyl, on_tap, show_owner=False):
        import os
        cond_color = th.condition_color(vinyl.condition)

        img_height = 160 if is_desktop else 130

        if vinyl.image_path and (vinyl.image_path.startswith("http")
                                   or os.path.exists(vinyl.image_path)):
            img = ft.Image(src=vinyl.image_path,
                           fit=ft.BoxFit.COVER,
                           width=float("inf"),
                           height=img_height)
        else:
            img = ft.Container(
                expand=True, bgcolor=th.SURFACE_VAR,
                alignment=ft.Alignment.CENTER,
                content=ft.Icon(ft.Icons.ALBUM, color=th.PRIMARY, size=50),
            )

        av_badge = []
        if vinyl.availability != "show":
            lbl = {"sale":"VENTA","trade":"CAMBIO","sale_trade":"V/C"}[vinyl.availability]
            av_badge = [ft.Container(
                padding=ft.padding.symmetric(horizontal=6, vertical=3),
                bgcolor=th.availability_color(vinyl.availability),
                border_radius=6,
                content=ft.Text(lbl, size=10,
                                weight=ft.FontWeight.BOLD, color="white"),
            )]

        price_badge = []
        if vinyl.price and vinyl.is_for_sale:
            price_badge = [ft.Container(
                padding=ft.padding.symmetric(horizontal=6, vertical=3),
                bgcolor=ft.Colors.with_opacity(0.8, "#000000"),
                border_radius=6,
                content=ft.Text(f"${vinyl.price:.0f}", size=11,
                                weight=ft.FontWeight.BOLD, color=th.ACCENT),
            )]

        meta = " · ".join(filter(None, [
            str(vinyl.year) if vinyl.year else "",
            vinyl.genre,
        ]))

        info_controls = [
            ft.Text(vinyl.title, size=13, weight=ft.FontWeight.BOLD,
                    color=th.ON_BG, max_lines=1,
                    overflow=ft.TextOverflow.ELLIPSIS),
            ft.Text(vinyl.artist, size=12, color=th.ON_SURFACE,
                    max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
            ft.Text(meta, size=11, color="#888888", max_lines=1),
            ft.Container(
                padding=ft.padding.symmetric(horizontal=5, vertical=2),
                border_radius=4,
                bgcolor=ft.Colors.with_opacity(0.15, cond_color),
                border=ft.border.all(1, ft.Colors.with_opacity(0.5, cond_color)),
                content=ft.Text(vinyl.condition_abbr, size=10,
                                weight=ft.FontWeight.W_600,
                                color=cond_color),
            ),
        ]
        if show_owner and vinyl.owner_name:
            info_controls.append(
                ft.Row(tight=True, spacing=3, controls=[
                    ft.Icon(ft.Icons.PERSON_OUTLINE, size=11, color="#888888"),
                    ft.Text(vinyl.owner_name, size=11, color="#888888",
                            max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                ])
            )

        card_pad    = 12  if is_desktop else 10

        return ft.Container(
            bgcolor=th.SURFACE,
            border_radius=16,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            shadow=ft.BoxShadow(
                blur_radius=8,
                color=ft.Colors.with_opacity(0.4, "#000000"),
                offset=ft.Offset(0, 4),
            ),
            on_click=on_tap,
            content=ft.Column(spacing=0, controls=[
                ft.Stack(height=img_height, controls=[
                    ft.Container(expand=True, content=img),
                    ft.Container(padding=6, content=ft.Row(
                        controls=av_badge,
                        alignment=ft.MainAxisAlignment.START,
                    )),
                    ft.Container(padding=6, content=ft.Row(
                        controls=price_badge,
                        alignment=ft.MainAxisAlignment.END,
                    )),
                ]),
                ft.Container(
                    padding=ft.padding.all(card_pad),
                    content=ft.Column(spacing=3, controls=info_controls),
                ),
            ]),
        )

    # ══════════════════════════════════════════════════════════════════════════
    # ARRANQUE
    # ══════════════════════════════════════════════════════════════════════════
    page.controls.append(shell)
    page.update()
    show_auth()


if __name__ == "__main__":
    ft.app(target=main)
