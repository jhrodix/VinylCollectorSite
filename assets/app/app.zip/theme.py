# ── Colores ──────────────────────────────────────────────────────────────────
BG            = "#0D0D0D"
SURFACE       = "#1A1A1A"
SURFACE_VAR   = "#242424"
PRIMARY       = "#E53935"
PRIMARY_DARK  = "#B71C1C"
ACCENT        = "#FFD600"
ON_BG         = "#EEEEEE"
ON_SURFACE    = "#CCCCCC"
DIVIDER       = "#2E2E2E"
CARD_SHADOW   = "#000000"

# ── Géneros ───────────────────────────────────────────────────────────────────
GENRES = [
    "Rock", "Pop", "Jazz", "Blues", "Soul", "Funk", "R&B", "Hip Hop",
    "Electronic", "Clásica", "Salsa", "Reggae", "Country", "Folk",
    "Metal", "Punk", "Latin", "Otro",
]

# ── Condiciones ───────────────────────────────────────────────────────────────
CONDITIONS = [
    "Mint (M)", "Near Mint (NM)", "Very Good Plus (VG+)",
    "Very Good (VG)", "Good Plus (G+)", "Good (G)", "Fair (F)", "Poor (P)",
]

def condition_color(cond: str) -> str:
    if cond.startswith("Mint"):            return "#4CAF50"
    if cond.startswith("Near Mint"):       return "#81C784"
    if cond.startswith("Very Good Plus"):  return "#29B6F6"
    if cond.startswith("Very Good"):       return "#4FC3F7"
    if cond.startswith("Good Plus"):       return "#FFB74D"
    if cond.startswith("Good"):            return "#FFA726"
    if cond.startswith("Fair"):            return "#EF9A9A"
    return "#BDBDBD"

def availability_color(av: str) -> str:
    return {"sale": "#4CAF50", "trade": "#29B6F6",
            "sale_trade": "#9C27B0"}.get(av, "#757575")

def availability_label(av: str) -> str:
    return {"show": "Solo Exhibición", "sale": "En Venta",
            "trade": "Para Intercambio", "sale_trade": "Venta / Intercambio"}.get(av, "")
