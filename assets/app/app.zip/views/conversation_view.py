import uuid
import random
from datetime import datetime
import flet as ft
import database as db
import theme as th
from models import Message


_AUTO_REPLIES = [
    "¡Hola! Gracias por tu mensaje. ¿En qué puedo ayudarte?",
    "¡Claro! Cuéntame más, estoy disponible para coordinar.",
    "Interesante propuesta. ¿Podemos hablar del precio?",
    "¡Sí, el vinilo está disponible! ¿Quieres más detalles?",
    "¡Perfecto! Dame un momento y te respondo con más info.",
]


def conversation_view(page: ft.Page,
                      user_id: str, user_name: str,
                      other_id: str, other_name: str,
                      vinyl_id: str | None, vinyl_title: str | None,
                      initial_msg: str | None,
                      on_back) -> ft.View:
    """Chat con otro coleccionista."""

    chat_list = ft.ListView(
        expand=True,
        spacing=8,
        padding=ft.padding.symmetric(horizontal=16, vertical=12),
        auto_scroll=True,
    )

    msg_field = ft.TextField(
        hint_text="Escribe un mensaje...",
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        border_radius=24,
        expand=True,
        multiline=True,
        min_lines=1,
        max_lines=4,
        shift_enter=True,
    )

    def load_messages():
        msgs = db.get_messages_with(user_id, other_id)
        chat_list.controls.clear()
        last_date = None
        for m in msgs:
            msg_date = _date_label(m.timestamp)
            if msg_date != last_date:
                chat_list.controls.append(
                    ft.Container(
                        alignment=ft.Alignment.CENTER,
                        padding=ft.padding.symmetric(vertical=8),
                        content=ft.Text(msg_date, size=11, color=th.ON_SURFACE),
                    )
                )
                last_date = msg_date
            chat_list.controls.append(_bubble(m, user_id))
        page.update()

    def send_message(_=None):
        text = msg_field.value.strip()
        if not text:
            return
        msg_field.value = ""

        m = Message(
            id            = uuid.uuid4().hex,
            sender_id     = user_id,
            sender_name   = user_name,
            receiver_id   = other_id,
            receiver_name = other_name,
            content       = text,
            vinyl_id      = vinyl_id,
            vinyl_title   = vinyl_title,
        )
        db.save_message(m)
        load_messages()

        # Respuesta automática simulada (demo)
        _auto_reply(other_id, other_name, user_id, user_name,
                    vinyl_id, vinyl_title, vinyl_title)

    def _auto_reply(sid, sname, rid, rname, vid, vtitle, _vt):
        # Solo si no hay respuestas previas del otro coleccionista
        prev = db.get_messages_with(user_id, other_id)
        other_has_replied = any(m.sender_id == other_id for m in prev)
        if other_has_replied:
            return
        reply_text = random.choice(_AUTO_REPLIES)
        if vinyl_title:
            reply_text = (
                f'¡Hola! Gracias por tu interés en "{vinyl_title}". '
                + random.choice([
                    "¿Tienes alguna pregunta sobre el estado del disco?",
                    "¿Te interesa coordinar el intercambio?",
                    "¿Quieres que te mande más fotos?",
                ])
            )
        auto = Message(
            id            = uuid.uuid4().hex,
            sender_id     = other_id,
            sender_name   = other_name,
            receiver_id   = user_id,
            receiver_name = user_name,
            content       = reply_text,
            vinyl_id      = vinyl_id,
            vinyl_title   = vinyl_title,
            timestamp     = datetime.now().isoformat(),
        )
        db.save_message(auto)
        load_messages()

    # Pre-cargar mensaje inicial si viene del detalle de vinilo
    if initial_msg:
        msg_field.value = initial_msg

    load_messages()

    appbar_subtitle = []
    if vinyl_title:
        appbar_subtitle = [ft.Text(
            f"📀 {vinyl_title}",
            size=11, color=th.PRIMARY,
        )]

    send_btn = ft.IconButton(
        icon=ft.Icons.SEND_ROUNDED,
        icon_color="white",
        bgcolor=th.PRIMARY,
        on_click=send_message,
        style=ft.ButtonStyle(
            shape=ft.CircleBorder(),
            padding=ft.padding.all(10),
        ),
    )

    input_bar = ft.Container(
        bgcolor=th.SURFACE,
        border=ft.border.only(top=ft.BorderSide(1, th.DIVIDER)),
        padding=ft.padding.symmetric(horizontal=12, vertical=8),
        content=ft.Row(
            spacing=8,
            controls=[msg_field, send_btn],
            vertical_alignment=ft.CrossAxisAlignment.END,
        ),
    )

    # Banda de contexto del vinilo
    vinyl_banner = []
    if vinyl_title:
        vinyl_banner = [ft.Container(
            bgcolor=ft.Colors.with_opacity(0.08, th.PRIMARY),
            padding=ft.padding.symmetric(horizontal=16, vertical=6),
            content=ft.Row(tight=True, spacing=6, controls=[
                ft.Icon(ft.Icons.ALBUM, size=14, color=th.PRIMARY),
                ft.Text(f"Conversación sobre: {vinyl_title}",
                        size=12, color=th.PRIMARY),
            ]),
        )]

    body = ft.Column(
        expand=True,
        spacing=0,
        controls=[
            *vinyl_banner,
            ft.Container(expand=True, content=chat_list),
            input_bar,
        ],
    )

    appbar = ft.Container(
        bgcolor=th.BG,
        padding=ft.padding.symmetric(horizontal=4, vertical=4),
        content=ft.Row(
            spacing=0,
            controls=[
                ft.IconButton(ft.Icons.ARROW_BACK, icon_color=th.ON_BG,
                              on_click=lambda _: on_back()),
                ft.Column(
                    spacing=0,
                    controls=[
                        ft.Text(other_name, color=th.ON_BG, size=15,
                                weight=ft.FontWeight.BOLD),
                        *appbar_subtitle,
                    ],
                ),
            ],
        ),
    )

    return ft.Column(
        expand=True,
        spacing=0,
        controls=[
            appbar,
            ft.Divider(height=1, color=th.DIVIDER),
            body,
        ],
    )


def _bubble(msg: Message, current_user_id: str) -> ft.Container:
    is_me = msg.sender_id == current_user_id
    time_str = datetime.fromisoformat(msg.timestamp).strftime("%H:%M")

    bubble = ft.Container(
        padding=ft.padding.symmetric(horizontal=14, vertical=10),
        border_radius=ft.border_radius.only(
            top_left=18, top_right=18,
            bottom_left=4 if is_me else 18,
            bottom_right=18 if is_me else 4,
        ),
        bgcolor=ft.Colors.with_opacity(0.85, th.PRIMARY) if is_me
                else th.SURFACE_VAR,
        shadow=ft.BoxShadow(
            blur_radius=4,
            color=ft.Colors.with_opacity(0.2, "#000000"),
            offset=ft.Offset(0, 2),
        ),
        content=ft.Column(
            spacing=3,
            tight=True,
            controls=[
                ft.Text(msg.content, size=14, color="white" if is_me
                        else th.ON_BG),
                ft.Text(time_str, size=10,
                        color=ft.Colors.with_opacity(0.6, "white") if is_me
                              else th.ON_SURFACE,
                        text_align=ft.TextAlign.RIGHT),
            ],
        ),
    )

    return ft.Container(
        alignment=ft.Alignment.CENTER_RIGHT if is_me
                   else ft.Alignment.CENTER_LEFT,
        content=ft.Container(
            width=320,
            content=bubble,
        ),
    )


def _date_label(ts: str) -> str:
    try:
        dt  = datetime.fromisoformat(ts)
        now = datetime.now()
        diff = (now.date() - dt.date()).days
        if diff == 0:  return "Hoy"
        if diff == 1:  return "Ayer"
        return dt.strftime("%d/%m/%Y")
    except Exception:
        return ""
