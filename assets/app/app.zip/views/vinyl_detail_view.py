import os
import flet as ft
import database as db
import theme as th
from models import Vinyl
from .components import avatar


def vinyl_detail_view(page: ft.Page, vinyl: Vinyl,
                      user_id: str, user_name: str,
                      is_owner: bool,
                      on_back, on_edit, on_contact, on_delete) -> ft.View:
    """Pantalla de detalle de un vinilo."""

    # ── Imagen de portada ─────────────────────────────────────────────────────
    if vinyl.image_path and (vinyl.image_path.startswith("http")
                              or os.path.exists(vinyl.image_path)):
        cover = ft.Container(
            height=300,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            content=ft.Image(
                src=vinyl.image_path,
                fit=ft.BoxFit.COVER,
                width=float("inf"),
                height=300,
            ),
        )
    else:
        cover = ft.Container(
            height=300,
            bgcolor=th.SURFACE_VAR,
            alignment=ft.Alignment.CENTER,
            content=ft.Icon(ft.Icons.ALBUM, size=120, color=th.PRIMARY),
        )

    # ── Badges de condición ───────────────────────────────────────────────────
    cond_color = th.condition_color(vinyl.condition)
    cond_badge = ft.Container(
        padding=ft.padding.symmetric(horizontal=10, vertical=6),
        border_radius=8,
        bgcolor=ft.Colors.with_opacity(0.1, cond_color),
        border=ft.border.all(1, ft.Colors.with_opacity(0.5, cond_color)),
        content=ft.Row(tight=True, spacing=5, controls=[
            ft.Container(width=8, height=8, border_radius=4,
                         bgcolor=cond_color),
            ft.Text(vinyl.condition_abbr, size=13,
                    weight=ft.FontWeight.W_600, color=cond_color),
        ]),
    )

    av = vinyl.availability
    av_badge_controls = []
    if av != "show":
        av_color = th.availability_color(av)
        av_badge_controls = [ft.Container(
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
            border_radius=8,
            bgcolor=ft.Colors.with_opacity(0.15, av_color),
            border=ft.border.all(1, ft.Colors.with_opacity(0.5, av_color)),
            content=ft.Text(vinyl.availability_label, size=13,
                            weight=ft.FontWeight.W_600, color=av_color),
        )]

    # ── Precio ────────────────────────────────────────────────────────────────
    price_section = []
    if vinyl.price and vinyl.is_for_sale:
        price_section = [ft.Container(
            padding=ft.padding.symmetric(horizontal=16, vertical=12),
            border_radius=12,
            bgcolor=th.SURFACE_VAR,
            border=ft.border.all(1, ft.Colors.with_opacity(0.3, th.ACCENT)),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Row(tight=True, spacing=6, controls=[
                        ft.Icon(ft.Icons.ATTACH_MONEY, color=th.ACCENT, size=24),
                        ft.Text(f"${vinyl.price:.2f} USD", size=22,
                                weight=ft.FontWeight.BOLD, color=th.ACCENT),
                    ]),
                    ft.Container(
                        visible=vinyl.is_for_trade,
                        padding=ft.padding.symmetric(horizontal=8, vertical=4),
                        border_radius=6,
                        bgcolor=ft.Colors.with_opacity(0.2, "#29B6F6"),
                        content=ft.Text("También acepta cambio",
                                        size=11, color="#29B6F6"),
                    ),
                ],
            ),
        )]
    elif vinyl.is_for_trade:
        price_section = [ft.Container(
            padding=ft.padding.symmetric(horizontal=16, vertical=12),
            border_radius=12,
            bgcolor=ft.Colors.with_opacity(0.1, "#29B6F6"),
            border=ft.border.all(1, ft.Colors.with_opacity(0.4, "#29B6F6")),
            content=ft.Row(tight=True, spacing=8, controls=[
                ft.Icon(ft.Icons.SWAP_HORIZ, color="#29B6F6", size=22),
                ft.Text("Disponible para intercambio",
                        size=14, color="#29B6F6"),
            ]),
        )]

    # ── Info del coleccionista (solo si no es dueño) ──────────────────────────
    owner_section = []
    if not is_owner:
        owner_section = [
            ft.Divider(color=th.DIVIDER),
            ft.Text("Coleccionista", size=16, weight=ft.FontWeight.BOLD,
                    color=th.ON_BG),
            ft.Row(spacing=12, controls=[
                avatar(vinyl.owner_name, radius=24),
                ft.Column(spacing=2, controls=[
                    ft.Text(vinyl.owner_name, size=15,
                            weight=ft.FontWeight.W_600, color=th.ON_BG),
                    ft.Text("Coleccionista de vinilos",
                            size=12, color=th.ON_SURFACE),
                ]),
            ]),
        ]

    # ── Botones de acción ─────────────────────────────────────────────────────
    action_buttons = []
    if not is_owner:
        action_buttons += [
            ft.ElevatedButton(
                "Contactar sobre este vinilo",
                icon=ft.Icons.MESSAGE,
                bgcolor=th.PRIMARY,
                color="white",
                expand=True,
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
                on_click=lambda _: on_contact(
                    vinyl,
                    f"¡Hola {vinyl.owner_name}! Vi tu vinilo "
                    f'"{vinyl.title}" de {vinyl.artist} y me interesa. '
                    f"¿Está disponible?"
                ),
            ),
        ]
        if vinyl.is_for_sale:
            action_buttons.append(
                ft.OutlinedButton(
                    "Hacer una oferta",
                    icon=ft.Icons.LOCAL_OFFER_OUTLINED,
                    expand=True,
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=12),
                        side=ft.BorderSide(color=th.PRIMARY, width=1.5),
                    ),
                    on_click=lambda _: _show_offer_dialog(page, vinyl,
                                                          user_id, user_name,
                                                          on_contact),
                )
            )

    # ── AppBar actions ────────────────────────────────────────────────────────
    appbar_actions = []
    if is_owner:
        appbar_actions = [
            ft.IconButton(ft.Icons.EDIT_OUTLINED, icon_color=th.PRIMARY,
                          tooltip="Editar", on_click=lambda _: on_edit(vinyl)),
            ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_color="#EF5350",
                          tooltip="Eliminar",
                          on_click=lambda _: _confirm_delete(
                              page, vinyl, on_delete)),
        ]

    # ── Layout ────────────────────────────────────────────────────────────────
    meta = []
    if vinyl.year:
        meta.append(ft.Container(
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
            border_radius=8, bgcolor=th.SURFACE_VAR,
            border=ft.border.all(1, th.DIVIDER),
            content=ft.Row(tight=True, spacing=5, controls=[
                ft.Icon(ft.Icons.CALENDAR_TODAY, size=13,
                        color=th.ON_SURFACE),
                ft.Text(str(vinyl.year), size=13, color=th.ON_SURFACE),
            ]),
        ))
    if vinyl.genre:
        meta.append(ft.Container(
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
            border_radius=8, bgcolor=th.SURFACE_VAR,
            border=ft.border.all(1, th.DIVIDER),
            content=ft.Row(tight=True, spacing=5, controls=[
                ft.Icon(ft.Icons.MUSIC_NOTE, size=13, color=th.ON_SURFACE),
                ft.Text(vinyl.genre, size=13, color=th.ON_SURFACE),
            ]),
        ))
    meta.append(cond_badge)
    meta += av_badge_controls

    body = ft.Column(
        scroll=ft.ScrollMode.AUTO,
        expand=True,
        spacing=0,
        controls=[
            cover,
            ft.Container(
                padding=20,
                content=ft.Column(
                    spacing=16,
                    controls=[
                        ft.Text(vinyl.title, size=26,
                                weight=ft.FontWeight.BOLD, color=th.ON_BG),
                        ft.Text(vinyl.artist, size=18,
                                weight=ft.FontWeight.W_500, color=th.PRIMARY),
                        ft.Row(wrap=True, spacing=8, run_spacing=8,
                               controls=meta),
                        *price_section,
                        *(
                            [ft.Column(spacing=6, controls=[
                                ft.Text("Descripción", size=16,
                                        weight=ft.FontWeight.BOLD,
                                        color=th.ON_BG),
                                ft.Text(vinyl.description, size=14,
                                        color=th.ON_SURFACE),
                            ])] if vinyl.description else []
                        ),
                        *owner_section,
                        *(
                            [ft.Row(spacing=10, controls=action_buttons)]
                            if action_buttons else []
                        ),
                        ft.Container(height=30),
                    ],
                ),
            ),
        ],
    )

    appbar = ft.Container(
        bgcolor=th.BG,
        padding=ft.padding.symmetric(horizontal=4, vertical=4),
        content=ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            controls=[
                ft.Row(
                    expand=True,
                    spacing=0,
                    controls=[
                        ft.IconButton(ft.Icons.ARROW_BACK, icon_color=th.ON_BG,
                                      on_click=lambda _: on_back()),
                        ft.Text(vinyl.title, size=18, color=th.ON_BG,
                                weight=ft.FontWeight.BOLD,
                                overflow=ft.TextOverflow.ELLIPSIS,
                                expand=True),
                    ],
                ),
                ft.Row(spacing=0, controls=appbar_actions),
            ],
        ),
    )

    return ft.Column(
        expand=True,
        spacing=0,
        controls=[
            appbar,
            ft.Divider(height=1, color=th.DIVIDER),
            body,
        ],
    )


def _confirm_delete(page, vinyl, on_delete):
    def do_delete(_):
        page.pop_dialog()
        db.delete_vinyl(vinyl.id)
        on_delete()

    dlg = ft.AlertDialog(
        modal=True,
        title=ft.Text("Eliminar vinilo", color=th.ON_BG),
        content=ft.Text(
            f'¿Eliminar "{vinyl.title}"? Esta acción no se puede deshacer.',
            color=th.ON_SURFACE,
        ),
        bgcolor=th.SURFACE_VAR,
        actions=[
            ft.TextButton("Cancelar", on_click=lambda _: page.pop_dialog()),
            ft.TextButton("Eliminar",
                          style=ft.ButtonStyle(color="#EF5350"),
                          on_click=do_delete),
        ],
    )
    page.show_dialog(dlg)


def _show_offer_dialog(page, vinyl, user_id, user_name, on_contact):
    suggested = f"${vinyl.price * 0.9:.0f}" if vinyl.price else ""
    f_offer = ft.TextField(
        value=suggested,
        hint_text="Tu oferta",
        bgcolor=th.SURFACE_VAR,
        color=th.ON_BG,
        border_radius=12,
        keyboard_type=ft.KeyboardType.NUMBER,
        prefix=ft.Text("$ "),
    )

    def send_offer(_):
        page.pop_dialog()
        on_contact(
            vinyl,
            f'¡Hola! Me interesa "{vinyl.title}". '
            f"Te ofrezco {f_offer.value} USD. ¿Lo considerarías?",
        )

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=th.SURFACE_VAR,
        title=ft.Text("Hacer una oferta", color=th.ON_BG),
        content=ft.Column(
            tight=True,
            controls=[
                ft.Text(
                    f"Precio pedido: ${vinyl.price:.2f}" if vinyl.price else "",
                    color=th.ON_SURFACE, size=13,
                ),
                f_offer,
            ],
        ),
        actions=[
            ft.TextButton("Cancelar", on_click=lambda _: page.pop_dialog()),
            ft.ElevatedButton("Enviar oferta", bgcolor=th.PRIMARY,
                              color="white", on_click=send_offer),
        ],
    )
    page.show_dialog(dlg)
