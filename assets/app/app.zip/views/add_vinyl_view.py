import uuid
import flet as ft
import database as db
import theme as th
from models import Vinyl


def add_vinyl_view(page: ft.Page, user_id: str, user_name: str,
                   existing: Vinyl | None, on_saved, on_back) -> ft.Control:
    """Pantalla para agregar o editar un vinilo. Adapta el layout según plataforma."""
    is_edit    = existing is not None
    title      = "Editar Vinilo" if is_edit else "Nuevo Vinilo"
    is_desktop = page.platform in (ft.PagePlatform.MACOS, ft.PagePlatform.WINDOWS)

    # ── Constantes de espaciado ────────────────────────────────────────────────
    PAD      = 20          # padding de secciones
    GAP      = 16          # separación entre grupos de campos
    INNER    = 6           # separación label → control

    # ── Estado de imagen ──────────────────────────────────────────────────────
    picked_path: list[str | None] = [existing.image_path if is_edit else None]

    # La imagen ocupa el ancho disponible en mobile (padding 20 a/l = full width).
    # En desktop el panel izquierdo tiene 260px - 2*20 = 220px de contenido,
    # así que fijamos la altura a 210px para mantener proporción cuadrada.
    IMG_H = 210 if is_desktop else 200

    img_preview = ft.Container(
        height=IMG_H,
        border_radius=12,
        bgcolor=th.SURFACE_VAR,
        border=ft.border.all(1.5, th.DIVIDER),
        clip_behavior=ft.ClipBehavior.HARD_EDGE,
    )

    def refresh_preview():
        p = picked_path[0]
        if p and (p.startswith("http") or __import__("os").path.exists(p)):
            # Sin expand — dimensiones explícitas para que BoxFit.COVER funcione
            img_preview.content = ft.Image(
                src=p,
                fit=ft.BoxFit.COVER,
                width=float("inf"),
                height=IMG_H,
            )
        else:
            img_preview.content = ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER,
                expand=True,
                spacing=8,
                controls=[
                    ft.Icon(ft.Icons.ADD_PHOTO_ALTERNATE_OUTLINED,
                            size=44,
                            color=ft.Colors.with_opacity(0.6, th.PRIMARY)),
                    ft.Text("Foto de portada",
                            size=13, color=th.ON_SURFACE),
                    ft.Text("Clic para seleccionar",
                            size=11, color="#666666"),
                ],
            )
        page.update()

    refresh_preview()

    # ── FilePicker ────────────────────────────────────────────────────────────
    # file_type=IMAGE hace que en móvil el OS ofrezca "Cámara" y "Galería".
    # En desktop abre el explorador de archivos.
    file_picker = ft.FilePicker()
    page.services.append(file_picker)
    page.update()

    async def do_pick_file():
        files = await file_picker.pick_files(
            file_type=ft.FilePickerFileType.IMAGE,
            allow_multiple=False,
        )
        if files:
            src = files[0].path
            if src:
                dst = db.copy_image(src)
                picked_path[0] = dst
            refresh_preview()

    img_preview.on_click = lambda _: page.run_task(do_pick_file)

    # ── Helpers de UI ─────────────────────────────────────────────────────────
    def lbl(text: str) -> ft.Text:
        return ft.Text(text, size=13, weight=ft.FontWeight.W_600,
                       color=th.ON_SURFACE)

    def group(label_text: str, control: ft.Control) -> ft.Column:
        return ft.Column(spacing=INNER, controls=[lbl(label_text), control])

    def field(hint: str, value: str = "",
              keyboard=ft.KeyboardType.TEXT,
              prefix_icon=None) -> ft.TextField:
        return ft.TextField(
            value=value,
            hint_text=hint,
            bgcolor=th.SURFACE_VAR,
            border_color=th.DIVIDER,
            focused_border_color=th.PRIMARY,
            color=th.ON_BG,
            hint_style=ft.TextStyle(color="#666666"),
            keyboard_type=keyboard,
            prefix_icon=prefix_icon,
            border_radius=12,
        )

    # ── Campos ────────────────────────────────────────────────────────────────
    f_title  = field("Ej: Kind of Blue",
                     existing.title if is_edit else "",
                     prefix_icon=ft.Icons.ALBUM)
    f_artist = field("Ej: Miles Davis",
                     existing.artist if is_edit else "",
                     prefix_icon=ft.Icons.PERSON)
    f_year   = field("1969",
                     str(existing.year) if (is_edit and existing.year) else "",
                     keyboard=ft.KeyboardType.NUMBER)
    f_price  = field("0.00",
                     str(existing.price) if (is_edit and existing.price) else "",
                     keyboard=ft.KeyboardType.NUMBER,
                     prefix_icon=ft.Icons.ATTACH_MONEY)
    f_desc   = ft.TextField(
        value=existing.description if is_edit else "",
        hint_text="Estado del disco, prensado, detalles especiales...",
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        multiline=True,
        min_lines=3,
        max_lines=5,
        border_radius=12,
    )

    dd_genre = ft.Dropdown(
        value=existing.genre if (is_edit and existing.genre) else None,
        hint_text="Seleccionar",
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        border_radius=12,
        options=[ft.dropdown.Option(g) for g in th.GENRES],
    )

    dd_cond = ft.Dropdown(
        value=existing.condition if is_edit else "Very Good (VG)",
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        border_radius=12,
        options=[ft.dropdown.Option(c) for c in th.CONDITIONS],
    )

    # ── Selector de disponibilidad ────────────────────────────────────────────
    current_av = [existing.availability if is_edit else "show"]
    av_options = [
        ("show",       ft.Icons.VISIBILITY,  "Solo exhibición", th.ON_SURFACE),
        ("sale",       ft.Icons.SELL,        "En venta",        "#4CAF50"),
        ("trade",      ft.Icons.SWAP_HORIZ,  "Intercambio",     "#29B6F6"),
        ("sale_trade", ft.Icons.STOREFRONT,  "Venta/Cambio",    "#9C27B0"),
    ]
    av_row    = ft.Row(wrap=True, spacing=8, run_spacing=8)
    price_row = ft.Column(visible=False, spacing=INNER,
                          controls=[lbl("Precio (USD)"), f_price])

    def update_av_row():
        av_row.controls.clear()
        for av_id, icon, av_lbl, color in av_options:
            selected = current_av[0] == av_id
            av_row.controls.append(ft.Container(
                padding=ft.padding.symmetric(horizontal=12, vertical=9),
                border_radius=10,
                bgcolor=ft.Colors.with_opacity(0.15 if selected else 0, color),
                border=ft.border.all(
                    1.5 if selected else 1,
                    color if selected else th.DIVIDER,
                ),
                on_click=lambda _, aid=av_id: select_av(aid),
                content=ft.Row(
                    tight=True, spacing=6,
                    controls=[
                        ft.Icon(icon, size=15,
                                color=color if selected else th.ON_SURFACE),
                        ft.Text(av_lbl, size=12,
                                color=color if selected else th.ON_SURFACE,
                                weight=(ft.FontWeight.BOLD if selected
                                        else ft.FontWeight.NORMAL)),
                    ],
                ),
            ))

    def select_av(av_id: str):
        current_av[0] = av_id
        price_row.visible = av_id in ("sale", "sale_trade")
        update_av_row()
        page.update()

    update_av_row()
    price_row.visible = current_av[0] in ("sale", "sale_trade")

    # ── Botón guardar ─────────────────────────────────────────────────────────
    save_btn = ft.ElevatedButton(
        "Actualizar Vinilo" if is_edit else "Agregar a Mi Colección",
        bgcolor=th.PRIMARY,
        color="white",
        height=48,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
        expand=True,
    )

    def do_save(_):
        f_title.error_text  = None
        f_artist.error_text = None
        has_error = False
        if not f_title.value.strip():
            f_title.error_text = "Ingresa el título"
            has_error = True
        if not f_artist.value.strip():
            f_artist.error_text = "Ingresa el artista"
            has_error = True
        if has_error:
            page.update()
            return

        year      = int(f_year.value) if f_year.value.strip().isdigit() else None
        price_str = f_price.value.strip().replace(",", ".")
        price     = float(price_str) if price_str else None

        v = Vinyl(
            id           = existing.id if is_edit else uuid.uuid4().hex,
            title        = f_title.value.strip(),
            artist       = f_artist.value.strip(),
            year         = year,
            genre        = dd_genre.value or "",
            condition    = dd_cond.value or "Very Good (VG)",
            price        = price,
            availability = current_av[0],
            image_path   = picked_path[0],
            description  = f_desc.value.strip(),
            owner_id     = user_id,
            owner_name   = user_name,
            created_at   = (existing.created_at if is_edit
                            else __import__("datetime").datetime.now().isoformat()),
        )
        db.save_vinyl(v)
        on_saved()

    save_btn.on_click = do_save

    # ── AppBar (idéntico al resto de la app) ──────────────────────────────────
    appbar = ft.Container(
        bgcolor=th.BG,
        padding=ft.padding.symmetric(horizontal=4, vertical=4),
        content=ft.Row(
            controls=[
                ft.IconButton(ft.Icons.ARROW_BACK,
                              icon_color=th.ON_BG,
                              on_click=lambda _: on_back()),
                ft.Text(title, size=20,
                        weight=ft.FontWeight.BOLD, color=th.ON_BG),
            ],
        ),
    )

    # ═════════════════════════════════════════════════════════════════════════
    # LAYOUT DESKTOP — dos paneles
    # Panel izq (260px): imagen + disponibilidad
    # Panel der (expand, scroll): campos del formulario + precio + guardar
    # ═════════════════════════════════════════════════════════════════════════
    if is_desktop:
        left_panel = ft.Container(
            width=260,
            padding=ft.padding.all(PAD),
            content=ft.Column(
                spacing=GAP,
                controls=[
                    img_preview,
                    ft.Divider(height=1, color=th.DIVIDER),
                    group("Disponibilidad", av_row),
                ],
            ),
        )

        right_panel = ft.Container(
            expand=True,
            padding=ft.padding.all(PAD),
            content=ft.Column(
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                spacing=GAP,
                controls=[
                    group("Título del álbum *", f_title),
                    group("Artista *", f_artist),
                    ft.Row(
                        spacing=12,
                        controls=[
                            ft.Column(expand=1, spacing=INNER,
                                      controls=[lbl("Año"), f_year]),
                            ft.Column(expand=2, spacing=INNER,
                                      controls=[lbl("Género"), dd_genre]),
                        ],
                    ),
                    group("Condición", dd_cond),
                    group("Descripción / Notas", f_desc),
                    price_row,
                    ft.Container(height=4),
                    ft.Row(controls=[save_btn]),
                    ft.Container(height=PAD),
                ],
            ),
        )

        return ft.Column(
            expand=True, spacing=0,
            controls=[
                appbar,
                ft.Divider(height=1, color=th.DIVIDER),
                ft.Row(
                    expand=True, spacing=0,
                    controls=[
                        left_panel,
                        ft.VerticalDivider(width=1, color=th.DIVIDER),
                        right_panel,
                    ],
                ),
            ],
        )

    # ═════════════════════════════════════════════════════════════════════════
    # LAYOUT MOBILE — columna única con scroll
    # ═════════════════════════════════════════════════════════════════════════
    return ft.Column(
        expand=True, spacing=0,
        controls=[
            appbar,
            ft.Divider(height=1, color=th.DIVIDER),
            ft.Column(
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                spacing=0,
                controls=[
                    ft.Container(
                        padding=ft.padding.all(PAD),
                        content=ft.Column(
                            spacing=GAP,
                            controls=[
                                img_preview,
                                group("Título del álbum *", f_title),
                                group("Artista *", f_artist),
                                ft.Row(
                                    spacing=12,
                                    controls=[
                                        ft.Column(expand=1, spacing=INNER,
                                                  controls=[lbl("Año"), f_year]),
                                        ft.Column(expand=2, spacing=INNER,
                                                  controls=[lbl("Género"), dd_genre]),
                                    ],
                                ),
                                group("Condición", dd_cond),
                                group("Disponibilidad", av_row),
                                price_row,
                                group("Descripción / Notas", f_desc),
                                ft.Container(height=4),
                                ft.Row(controls=[save_btn]),
                                ft.Container(height=PAD),
                            ],
                        ),
                    ),
                ],
            ),
        ],
    )
