from datetime import datetime
import flet as ft
import database as db
import theme as th
from .components import avatar


def inbox_view(page: ft.Page, user_id: str, user_name: str,
               on_open_conversation) -> ft.View:
    """Pantalla de mensajes — lista de conversaciones."""

    list_view = ft.ListView(expand=True, spacing=0, padding=0)

    def load():
        convs = db.get_conversations(user_id)
        list_view.controls.clear()

        if not convs:
            list_view.controls.append(
                ft.Container(
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=12,
                        controls=[
                            ft.Icon(ft.Icons.MARK_CHAT_UNREAD_OUTLINED,
                                    size=72,
                                    color=ft.Colors.with_opacity(0.3, th.ON_SURFACE)),
                            ft.Text("Sin mensajes aún", size=20,
                                    weight=ft.FontWeight.BOLD, color=th.ON_BG),
                            ft.Text(
                                "Cuando contactes a un coleccionista\n"
                                "los mensajes aparecerán aquí",
                                size=14, color=th.ON_SURFACE,
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                    ),
                )
            )
        else:
            for conv in convs:
                last   = conv.last_message
                unread = conv.unread_count
                ts_str = _fmt_time(last.timestamp) if last else ""

                list_view.controls.append(
                    ft.Container(
                        padding=ft.padding.symmetric(horizontal=16, vertical=12),
                        on_click=lambda _, c=conv: _open(c),
                        ink=True,
                        content=ft.Row(
                            spacing=12,
                            controls=[
                                ft.Stack(
                                    width=52,
                                    height=52,
                                    controls=[
                                        ft.Container(
                                            content=avatar(conv.other_user_name,
                                                           radius=26),
                                        ),
                                        *(
                                            [ft.Container(
                                                width=14, height=14,
                                                border_radius=7,
                                                bgcolor=th.PRIMARY,
                                                right=0, top=0,
                                            )]
                                            if unread > 0 else []
                                        ),
                                    ],
                                ),
                                ft.Column(
                                    expand=True,
                                    spacing=3,
                                    controls=[
                                        ft.Row(
                                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                            controls=[
                                                ft.Text(
                                                    conv.other_user_name,
                                                    size=15,
                                                    weight=ft.FontWeight.BOLD
                                                           if unread > 0
                                                           else ft.FontWeight.NORMAL,
                                                    color=th.ON_BG,
                                                ),
                                                ft.Text(
                                                    ts_str, size=11,
                                                    color=th.PRIMARY if unread > 0
                                                          else th.ON_SURFACE,
                                                ),
                                            ],
                                        ),
                                        *(
                                            [ft.Text(
                                                f"📀 {conv.vinyl_title}",
                                                size=11, color=th.PRIMARY,
                                                weight=ft.FontWeight.W_500,
                                            )]
                                            if conv.vinyl_title else []
                                        ),
                                        ft.Text(
                                            last.content if last else "",
                                            size=13,
                                            color=th.ON_BG if unread > 0
                                                  else th.ON_SURFACE,
                                            weight=ft.FontWeight.W_500 if unread > 0
                                                   else ft.FontWeight.NORMAL,
                                            max_lines=1,
                                            overflow=ft.TextOverflow.ELLIPSIS,
                                        ),
                                    ],
                                ),
                                *(
                                    [ft.Container(
                                        width=22, height=22, border_radius=11,
                                        bgcolor=th.PRIMARY,
                                        alignment=ft.Alignment.CENTER,
                                        content=ft.Text(str(unread), size=10,
                                                        color="white",
                                                        weight=ft.FontWeight.BOLD),
                                    )]
                                    if unread > 0 else []
                                ),
                            ],
                        ),
                    ),
                )
                list_view.controls.append(
                    ft.Divider(height=1, color=th.DIVIDER)
                )
        page.update()

    def _open(conv):
        db.mark_as_read(user_id, conv.other_user_id)
        on_open_conversation(conv)

    load()

    return ft.View(
        "/inbox",
        bgcolor=th.BG,
        appbar=ft.AppBar(
            title=ft.Text("Mensajes", color=th.ON_BG,
                          weight=ft.FontWeight.BOLD),
            bgcolor=th.BG,
            actions=[
                ft.IconButton(ft.Icons.REFRESH_OUTLINED,
                              icon_color=th.ON_SURFACE,
                              tooltip="Actualizar",
                              on_click=lambda _: load()),
            ],
        ),
        controls=[list_view],
    )


def _fmt_time(ts: str) -> str:
    try:
        dt  = datetime.fromisoformat(ts)
        now = datetime.now()
        diff = now - dt
        if diff.days == 0:
            return dt.strftime("%H:%M")
        if diff.days == 1:
            return "Ayer"
        if diff.days < 7:
            days = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
            return days[dt.weekday()]
        return dt.strftime("%d/%m")
    except Exception:
        return ""
