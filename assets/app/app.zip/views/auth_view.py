"""
Pantalla de Login / Registro para Vinyl Collector.
Llama a on_success(user_id, username) cuando la autenticación es exitosa.
"""
import flet as ft
import database as db
import theme as th


def auth_view(page: ft.Page, on_success) -> None:
    """
    Reemplaza el contenido de la página con la pantalla de auth.
    on_success(user_id: str, username: str) se llama al autenticarse.
    """

    # ── Estado interno ────────────────────────────────────────────────────────
    showing_login = [True]   # [True] = login, [False] = registro

    # ── Campos ───────────────────────────────────────────────────────────────
    f_username = ft.TextField(
        hint_text="Nombre de usuario",
        prefix_icon=ft.Icons.PERSON_OUTLINE,
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        border_radius=12,
        autofocus=True,
        on_submit=lambda _: f_password.focus(),
    )

    f_password = ft.TextField(
        hint_text="Contraseña",
        prefix_icon=ft.Icons.LOCK_OUTLINE,
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        border_radius=12,
        password=True,
        can_reveal_password=True,
        on_submit=lambda _: _handle_submit(),
    )

    f_password_confirm = ft.TextField(
        hint_text="Confirmar contraseña",
        prefix_icon=ft.Icons.LOCK_OUTLINE,
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        border_radius=12,
        password=True,
        can_reveal_password=True,
        visible=False,
        on_submit=lambda _: _handle_submit(),
    )

    error_text = ft.Text("", color="#EF5350", size=13,
                         text_align=ft.TextAlign.CENTER)

    btn_submit = ft.ElevatedButton(
        "Iniciar Sesión",
        bgcolor=th.PRIMARY,
        color="white",
        expand=False,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
        on_click=lambda _: _handle_submit(),
    )

    lbl_toggle_hint = ft.Text(
        "¿No tienes cuenta?",
        size=13, color=th.ON_SURFACE,
    )

    btn_toggle = ft.TextButton(
        "Regístrate",
        style=ft.ButtonStyle(color=th.PRIMARY),
        on_click=lambda _: _toggle_mode(),
    )

    title_text  = ft.Text(
        "Vinyl Collector",
        size=32, weight=ft.FontWeight.BOLD, color=th.ON_BG,
    )
    subtitle_text = ft.Text(
        "Inicia sesión para continuar",
        size=14, color=th.ON_SURFACE,
    )

    # ── Lógica ───────────────────────────────────────────────────────────────
    def _clear_errors():
        error_text.value     = ""
        f_username.error_text = ""
        f_password.error_text = ""
        f_password_confirm.error_text = ""

    def _toggle_mode():
        _clear_errors()
        showing_login[0] = not showing_login[0]
        is_login = showing_login[0]

        subtitle_text.value         = ("Inicia sesión para continuar"
                                       if is_login else "Crea tu cuenta")
        btn_submit.text             = "Iniciar Sesión" if is_login else "Crear Cuenta"
        f_password_confirm.visible  = not is_login
        lbl_toggle_hint.value       = ("¿No tienes cuenta?"
                                       if is_login else "¿Ya tienes cuenta?")
        btn_toggle.text             = "Regístrate" if is_login else "Inicia Sesión"
        page.update()

    def _handle_submit():
        _clear_errors()
        username = f_username.value.strip()
        password = f_password.value

        # Validaciones básicas
        has_error = False
        if not username:
            f_username.error_text = "Ingresa tu nombre de usuario"
            has_error = True
        elif len(username) < 3:
            f_username.error_text = "Mínimo 3 caracteres"
            has_error = True

        if not password:
            f_password.error_text = "Ingresa tu contraseña"
            has_error = True
        elif len(password) < 6:
            f_password.error_text = "Mínimo 6 caracteres"
            has_error = True

        if not showing_login[0]:
            confirm = f_password_confirm.value
            if not confirm:
                f_password_confirm.error_text = "Confirma tu contraseña"
                has_error = True
            elif password != confirm:
                f_password_confirm.error_text = "Las contraseñas no coinciden"
                has_error = True

        if has_error:
            page.update()
            return

        # Login
        if showing_login[0]:
            result = db.login_user(username, password)
            if result is None:
                error_text.value = "Usuario o contraseña incorrectos."
                page.update()
                return
            user_id, user_name = result
            on_success(user_id, user_name)

        # Registro
        else:
            ok, payload = db.register_user(username, password)
            if not ok:
                error_text.value = payload   # mensaje de error
                page.update()
                return
            user_id = payload
            on_success(user_id, username)

    # ── Layout ────────────────────────────────────────────────────────────────
    content = ft.Container(
        expand=True,
        bgcolor=th.BG,
        alignment=ft.Alignment.CENTER,
        padding=32,
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=16,
            controls=[
                ft.Icon(ft.Icons.ALBUM, size=90, color=th.PRIMARY),
                title_text,
                subtitle_text,
                ft.Container(height=4),
                f_username,
                f_password,
                f_password_confirm,
                error_text,
                btn_submit,
                ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[lbl_toggle_hint, btn_toggle],
                ),
            ],
        ),
    )

    page.controls.clear()
    page.controls.append(content)
    page.update()
