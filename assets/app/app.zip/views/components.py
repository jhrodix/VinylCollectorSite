"""Widgets reutilizables compartidos entre vistas."""
import os
import flet as ft
import theme as th
from models import Vinyl


# ── Vinyl Card ────────────────────────────────────────────────────────────────
def vinyl_card(vinyl: Vinyl, on_tap) -> ft.Container:
    # Imagen o placeholder
    if vinyl.image_path and (vinyl.image_path.startswith("http")
                              or os.path.exists(vinyl.image_path)):
        image = ft.Image(
            src=vinyl.image_path,
            fit=ft.BoxFit.COVER,
            width=float("inf"),
            height=140,
        )
    else:
        image = ft.Container(
            expand=True,
            bgcolor=th.SURFACE_VAR,
            content=ft.Icon(ft.Icons.ALBUM, color=th.PRIMARY, size=56),
            alignment=ft.Alignment.CENTER,
        )

    # Disponibilidad badge
    av = vinyl.availability
    av_badge = []
    if av != "show":
        label = {"sale": "VENTA", "trade": "CAMBIO", "sale_trade": "V/C"}[av]
        av_badge = [ft.Container(
            padding=ft.padding.symmetric(horizontal=6, vertical=3),
            bgcolor=th.availability_color(av),
            border_radius=6,
            content=ft.Text(label, size=10, weight=ft.FontWeight.BOLD, color="white"),
        )]

    # Precio badge
    price_badge = []
    if vinyl.price and vinyl.is_for_sale:
        price_badge = [ft.Container(
            padding=ft.padding.symmetric(horizontal=6, vertical=3),
            bgcolor=ft.Colors.with_opacity(0.8, "#000000"),
            border_radius=6,
            content=ft.Text(f"${vinyl.price:.0f}", size=11,
                            weight=ft.FontWeight.BOLD, color=th.ACCENT),
        )]

    # Condición badge
    cond_color = th.condition_color(vinyl.condition)
    cond_badge = ft.Container(
        padding=ft.padding.symmetric(horizontal=5, vertical=2),
        border_radius=4,
        bgcolor=ft.Colors.with_opacity(0.15, cond_color),
        border=ft.border.all(1, ft.Colors.with_opacity(0.5, cond_color)),
        content=ft.Text(vinyl.condition_abbr, size=10,
                        weight=ft.FontWeight.W_600, color=cond_color),
    )

    meta_parts = []
    if vinyl.year:
        meta_parts.append(str(vinyl.year))
    if vinyl.genre:
        meta_parts.append(vinyl.genre)

    card = ft.Container(
        width=200,
        bgcolor=th.SURFACE,
        border_radius=16,
        clip_behavior=ft.ClipBehavior.HARD_EDGE,
        shadow=ft.BoxShadow(blur_radius=8, color=ft.Colors.with_opacity(0.4, "#000000"),
                            offset=ft.Offset(0, 4)),
        on_click=on_tap,
        content=ft.Column(
            spacing=0,
            controls=[
                # Imagen
                ft.Stack(
                    height=140,
                    controls=[
                        ft.Container(expand=True, content=image),
                        ft.Container(
                            padding=6,
                            content=ft.Row(
                                controls=av_badge,
                                alignment=ft.MainAxisAlignment.START,
                            ),
                        ),
                        ft.Container(
                            padding=6,
                            content=ft.Row(
                                controls=price_badge,
                                alignment=ft.MainAxisAlignment.END,
                            ),
                        ),
                    ],
                ),
                # Info
                ft.Container(
                    padding=ft.padding.all(10),
                    content=ft.Column(
                        spacing=3,
                        controls=[
                            ft.Text(vinyl.title, size=13,
                                    weight=ft.FontWeight.BOLD,
                                    color=th.ON_BG, max_lines=1,
                                    overflow=ft.TextOverflow.ELLIPSIS),
                            ft.Text(vinyl.artist, size=12,
                                    color=th.ON_SURFACE, max_lines=1,
                                    overflow=ft.TextOverflow.ELLIPSIS),
                            ft.Text(" · ".join(meta_parts), size=11,
                                    color="#888888", max_lines=1),
                            cond_badge,
                        ],
                    ),
                ),
            ],
        ),
    )
    return card


# ── Owner avatar ──────────────────────────────────────────────────────────────
def avatar(name: str, radius: int = 20) -> ft.CircleAvatar:
    return ft.CircleAvatar(
        content=ft.Text(
            name[0].upper() if name else "?",
            size=radius * 0.9,
            weight=ft.FontWeight.BOLD,
            color=th.PRIMARY,
        ),
        bgcolor=ft.Colors.with_opacity(0.2, th.PRIMARY),
        radius=radius,
    )


# ── Empty states ──────────────────────────────────────────────────────────────
def empty_collection(on_add) -> ft.Container:
    return ft.Container(
        expand=True,
        alignment=ft.Alignment.CENTER,
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                ft.Icon(ft.Icons.ALBUM_OUTLINED, size=80,
                        color=ft.Colors.with_opacity(0.3, th.PRIMARY)),
                ft.Text("Tu colección está vacía", size=20,
                        weight=ft.FontWeight.BOLD, color=th.ON_BG),
                ft.Text("Agrega tu primer vinilo para comenzar",
                        size=14, color=th.ON_SURFACE),
                ft.ElevatedButton(
                    "Agregar Primer Vinilo",
                    icon=ft.Icons.ADD,
                    bgcolor=th.PRIMARY,
                    color="white",
                    on_click=lambda _: on_add(),
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=12),
                    ),
                ),
            ],
            spacing=12,
        ),
    )
