import flet as ft
import database as db
import theme as th
from models import Vinyl
from .components import vinyl_card, empty_collection


def home_view(page: ft.Page, user_id: str, user_name: str,
              on_add, on_open_vinyl) -> ft.View:
    """Pantalla principal — colección del usuario en grid de cards."""

    grid = ft.GridView(
        expand=True,
        runs_count=2,
        max_extent=220,
        child_aspect_ratio=0.62,
        spacing=12,
        run_spacing=12,
        padding=16,
    )

    title_text = ft.Text(
        "Mi Colección",
        size=24,
        weight=ft.FontWeight.BOLD,
        color=th.ON_BG,
    )
    count_text = ft.Text("", size=12, color=th.ON_SURFACE)

    def load_vinyls():
        vinyls = db.get_my_vinyls(user_id)
        count_text.value = f"{len(vinyls)} vinilo{'s' if len(vinyls) != 1 else ''}"
        grid.controls.clear()
        if not vinyls:
            grid.controls.append(empty_collection(on_add))
        else:
            for v in vinyls:
                grid.controls.append(
                    vinyl_card(v, lambda e, vinyl=v: on_open_vinyl(vinyl))
                )
        page.update()

    load_vinyls()

    return ft.View(
        "/",
        bgcolor=th.BG,
        appbar=ft.AppBar(
            bgcolor=th.BG,
            title=ft.Column(
                spacing=0,
                controls=[title_text, count_text],
            ),
            actions=[
                ft.IconButton(
                    ft.Icons.REFRESH_OUTLINED,
                    icon_color=th.ON_SURFACE,
                    on_click=lambda _: load_vinyls(),
                    tooltip="Actualizar",
                ),
            ],
        ),
        floating_action_button=ft.FloatingActionButton(
            icon=ft.Icons.ADD,
            text="Agregar Vinilo",
            bgcolor=th.PRIMARY,
            on_click=lambda _: on_add(),
        ),
        controls=[grid],
    )
