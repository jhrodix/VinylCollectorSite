import flet as ft
import database as db
import theme as th
from .components import vinyl_card


def marketplace_view(page: ft.Page, user_id: str, user_name: str,
                     on_open_vinyl) -> ft.View:
    """Marketplace — vinilos de otros coleccionistas."""

    search_query = ft.Ref[str]()
    search_query.current = ""
    filter_genre = ft.Ref[str | None]()
    filter_genre.current = None
    current_tab  = ft.Ref[int]()
    current_tab.current = 0   # 0=Todo 1=Venta 2=Cambio

    grid = ft.GridView(
        expand=True,
        runs_count=2,
        max_extent=220,
        child_aspect_ratio=0.58,
        spacing=12,
        run_spacing=12,
        padding=16,
    )

    genre_chip_row = ft.Row(
        scroll=ft.ScrollMode.AUTO,
        spacing=8,
        visible=False,
    )

    # ── Carga y filtro ────────────────────────────────────────────────────────
    def load(tab: int = 0):
        current_tab.current = tab
        all_v = db.get_marketplace_vinyls(user_id)
        q     = search_query.current.lower()
        g     = filter_genre.current

        filtered = [
            v for v in all_v
            if (tab == 0 or (tab == 1 and v.is_for_sale) or
                (tab == 2 and v.is_for_trade))
            and (not g or v.genre.lower() == g.lower())
            and (not q or q in v.title.lower() or
                 q in v.artist.lower() or q in v.genre.lower())
        ]

        grid.controls.clear()
        if not filtered:
            grid.controls.append(
                ft.Container(
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            ft.Icon(ft.Icons.SEARCH_OFF, size=64,
                                    color=ft.Colors.with_opacity(0.3, th.ON_SURFACE)),
                            ft.Text("Sin resultados", size=18,
                                    weight=ft.FontWeight.BOLD, color=th.ON_BG),
                            ft.Text("Intenta con otros filtros",
                                    size=14, color=th.ON_SURFACE),
                        ],
                    ),
                )
            )
        else:
            for v in filtered:
                grid.controls.append(
                    vinyl_card(v, lambda e, vinyl=v: on_open_vinyl(vinyl),
                               show_owner=True)
                )
        page.update()

    def on_search(e):
        search_query.current = e.control.value
        load(current_tab.current)

    def select_genre(g: str | None):
        filter_genre.current = g
        genre_chip_row.visible = g is not None
        genre_chip_row.controls.clear()
        if g:
            genre_chip_row.controls.append(
                ft.Chip(
                    label=ft.Text(g, color=th.PRIMARY),
                    bgcolor=ft.Colors.with_opacity(0.15, th.PRIMARY),
                    delete_icon_color=th.PRIMARY,
                    on_delete=lambda _: select_genre(None),
                )
            )
        load(current_tab.current)

    def show_filter_dialog(_):
        chips = []
        for g in th.GENRES:
            sel = filter_genre.current == g
            chips.append(ft.Container(
                padding=ft.padding.symmetric(horizontal=12, vertical=8),
                border_radius=8,
                bgcolor=ft.Colors.with_opacity(0.15 if sel else 0, th.PRIMARY),
                border=ft.border.all(1, th.PRIMARY if sel else th.DIVIDER),
                on_click=lambda _, genre=g: (page.pop_dialog(), select_genre(genre)),
                content=ft.Text(g, color=th.PRIMARY if sel else th.ON_SURFACE,
                                size=13),
            ))
        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=th.SURFACE_VAR,
            title=ft.Text("Filtrar por Género", color=th.ON_BG),
            content=ft.Container(
                width=400,
                content=ft.Column(
                    scroll=ft.ScrollMode.AUTO,
                    height=300,
                    controls=[ft.Row(wrap=True, spacing=8, run_spacing=8,
                                     controls=chips)],
                ),
            ),
            actions=[
                ft.TextButton(
                    "Limpiar filtro",
                    on_click=lambda _: (page.pop_dialog(), select_genre(None)),
                ),
                ft.TextButton("Cerrar",
                              on_click=lambda _: page.pop_dialog()),
            ],
        )
        page.show_dialog(dlg)

    # ── Tabs ──────────────────────────────────────────────────────────────────
    tabs = ft.Tabs(
        selected_index=0,
        indicator_color=th.PRIMARY,
        label_color=th.PRIMARY,
        unselected_label_color=th.ON_SURFACE,
        tabs=[
            ft.Tab(label="Todo"),
            ft.Tab(label="En Venta"),
            ft.Tab(label="Intercambio"),
        ],
        on_change=lambda e: load(e.control.selected_index),
    )

    search_bar = ft.TextField(
        hint_text="Buscar artista, álbum, género...",
        prefix_icon=ft.Icons.SEARCH,
        bgcolor=th.SURFACE_VAR,
        border_color=th.DIVIDER,
        focused_border_color=th.PRIMARY,
        color=th.ON_BG,
        hint_style=ft.TextStyle(color="#666666"),
        border_radius=12,
        suffix=ft.IconButton(
            ft.Icons.FILTER_LIST_OUTLINED,
            icon_color=th.ON_SURFACE,
            tooltip="Filtrar por género",
            on_click=show_filter_dialog,
        ),
        on_change=on_search,
    )

    load(0)

    return ft.View(
        "/marketplace",
        bgcolor=th.BG,
        appbar=ft.AppBar(
            title=ft.Text("Marketplace", color=th.ON_BG,
                          weight=ft.FontWeight.BOLD),
            bgcolor=th.BG,
        ),
        controls=[
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    ft.Container(
                        padding=ft.Padding.only(left=16, top=12, right=16, bottom=0),
                        content=search_bar,
                    ),
                    ft.Container(
                        padding=ft.padding.symmetric(horizontal=16, vertical=4),
                        content=genre_chip_row,
                    ),
                    ft.Container(
                        padding=ft.padding.symmetric(horizontal=16),
                        content=tabs,
                    ),
                    grid,
                ],
            ),
        ],
    )


# Parche para pasar show_owner al card
def vinyl_card(vinyl, on_tap, show_owner=False):
    from .components import vinyl_card as _vc
    card = _vc(vinyl, on_tap)
    if show_owner and vinyl.owner_name:
        from .components import avatar
        import flet as ft
        # Agregar nombre del dueño al card
        inner = card.content
        if hasattr(inner, "controls") and len(inner.controls) > 1:
            info_col = inner.controls[1].content
            if hasattr(info_col, "controls"):
                info_col.controls.append(
                    ft.Row(tight=True, spacing=3, controls=[
                        ft.Icon(ft.Icons.PERSON_OUTLINE, size=11,
                                color="#888888"),
                        ft.Text(vinyl.owner_name, size=11, color="#888888",
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS),
                    ])
                )
    return card
