from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List


@dataclass
class Vinyl:
    id: str
    title: str
    artist: str
    year: Optional[int]       = None
    genre: str                = ""
    condition: str            = "Very Good (VG)"
    price: Optional[float]   = None
    availability: str        = "show"   # show | sale | trade | sale_trade
    image_path: Optional[str] = None
    description: str          = ""
    owner_id: str             = ""
    owner_name: str           = ""
    created_at: str           = field(
        default_factory=lambda: datetime.now().isoformat()
    )
    is_sample: bool           = False

    @property
    def is_for_sale(self)  -> bool:
        return self.availability in ("sale", "sale_trade")

    @property
    def is_for_trade(self) -> bool:
        return self.availability in ("trade", "sale_trade")

    @property
    def availability_label(self) -> str:
        return {
            "show":       "Solo Exhibición",
            "sale":       "En Venta",
            "trade":      "Para Intercambio",
            "sale_trade": "Venta / Intercambio",
        }.get(self.availability, "")

    @property
    def condition_abbr(self) -> str:
        """Devuelve la abreviación entre paréntesis, p.ej. 'NM'."""
        if "(" in self.condition:
            return self.condition[self.condition.index("(") + 1:
                                  self.condition.index(")")]
        return self.condition


@dataclass
class Message:
    id: str
    sender_id: str
    sender_name: str
    receiver_id: str
    receiver_name: str
    content: str
    vinyl_id: Optional[str]    = None
    vinyl_title: Optional[str] = None
    timestamp: str             = field(
        default_factory=lambda: datetime.now().isoformat()
    )
    is_read: bool              = False


@dataclass
class Conversation:
    other_user_id: str
    other_user_name: str
    messages: List[Message]
    vinyl_id: Optional[str]    = None
    vinyl_title: Optional[str] = None

    @property
    def last_message(self) -> Optional[Message]:
        return self.messages[-1] if self.messages else None

    @property
    def unread_count(self) -> int:
        return sum(1 for m in self.messages if not m.is_read)
