"""
Servicio de base de datos Supabase para Vinyl Collector.

Configura las credenciales con variables de entorno o un archivo .env:
    SUPABASE_URL         = https://xxxx.supabase.co
    SUPABASE_KEY         = eyJ...   (anon/public key)
    SUPABASE_SERVICE_KEY = eyJ...   (service_role key — solo para storage)

La SERVICE_KEY se obtiene en:
  Supabase Dashboard → Project Settings → API → service_role (secret)
"""
import hashlib
import os
import time
import uuid
import mimetypes
from datetime import datetime
from typing import List, Optional, Tuple

from supabase import create_client, Client

from models import Conversation, Message, Vinyl

# ── Credenciales ──────────────────────────────────────────────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

SUPABASE_URL:         str = os.environ.get("SUPABASE_URL", "")
SUPABASE_KEY:         str = os.environ.get("SUPABASE_KEY", "")
SUPABASE_SERVICE_KEY: str = os.environ.get("SUPABASE_SERVICE_KEY", "")
BUCKET:               str = "vinyl-images"

_client:         Optional[Client] = None
_storage_client: Optional[Client] = None

# Caché de signed URLs: { filename → (signed_url, expiry_timestamp) }
_URL_CACHE:      dict[str, tuple[str, float]] = {}
_URL_TTL:        int = 3600   # 1 hora en segundos


def _sb() -> Client:
    """Cliente con anon key — para todas las operaciones de base de datos."""
    global _client
    if _client is None:
        if not SUPABASE_URL or not SUPABASE_KEY:
            raise RuntimeError(
                "Faltan credenciales de Supabase. "
                "Define SUPABASE_URL y SUPABASE_KEY en el archivo .env"
            )
        _client = create_client(SUPABASE_URL, SUPABASE_KEY)
    return _client


def _sb_storage() -> Client:
    """Cliente con service_role key — solo para subir archivos a Storage."""
    global _storage_client
    if _storage_client is None:
        key = SUPABASE_SERVICE_KEY or SUPABASE_KEY   # fallback a anon si no hay service key
        if not SUPABASE_URL or not key:
            raise RuntimeError(
                "Faltan credenciales de Supabase. "
                "Define SUPABASE_URL y SUPABASE_SERVICE_KEY en el archivo .env"
            )
        _storage_client = create_client(SUPABASE_URL, key)
    return _storage_client


# ── Inicialización ────────────────────────────────────────────────────────────
def init_db() -> None:
    """Verifica la conexión y crea el bucket de imágenes si no existe."""
    _sb()
    _ensure_bucket()


def _ensure_bucket() -> None:
    """Crea el bucket de imágenes privado si todavía no existe."""
    storage = _sb_storage().storage
    buckets = [b.name for b in storage.list_buckets()]
    if BUCKET not in buckets:
        storage.create_bucket(BUCKET, options={"public": False})


# ── Settings (usuario) ────────────────────────────────────────────────────────
def get_setting(key: str) -> Optional[str]:
    res = _sb().table("settings").select("value").eq("key", key).execute()
    return res.data[0]["value"] if res.data else None


def set_setting(key: str, value: str) -> None:
    _sb().table("settings").upsert({"key": key, "value": value}).execute()


# ── Vinyls ────────────────────────────────────────────────────────────────────
def _resolve_image(raw: Optional[str]) -> Optional[str]:
    """
    Convierte el filename guardado en DB en una signed URL válida.
    Si el valor ya era una URL pública (migración), extrae el filename primero.
    Las URLs se cachean durante _URL_TTL segundos.
    """
    if not raw:
        return None
    # Compatibilidad con vinyls viejos que guardaban la URL pública completa
    filename = raw.split("/")[-1] if raw.startswith("http") else raw

    cached_url, expires_at = _URL_CACHE.get(filename, (None, 0.0))
    if cached_url and time.time() < expires_at - 60:   # 60 s de margen
        return cached_url

    res     = _sb_storage().storage.from_(BUCKET).create_signed_url(filename, _URL_TTL)
    new_url = res.get("signedURL") or res.get("signed_url", "")
    _URL_CACHE[filename] = (new_url, time.time() + _URL_TTL)
    return new_url


def _row_to_vinyl(row: dict) -> Vinyl:
    return Vinyl(
        id           = row["id"],
        title        = row["title"],
        artist       = row["artist"],
        year         = row.get("year"),
        genre        = row.get("genre") or "",
        condition    = row.get("condition") or "Very Good (VG)",
        price        = row.get("price"),
        availability = row.get("availability") or "show",
        image_path   = _resolve_image(row.get("image_path")),
        description  = row.get("description") or "",
        owner_id     = row["owner_id"],
        owner_name   = row["owner_name"],
        created_at   = row["created_at"],
        is_sample    = bool(row.get("is_sample", False)),
    )


def get_my_vinyls(owner_id: str) -> List[Vinyl]:
    res = (
        _sb().table("vinyls")
        .select("*")
        .eq("owner_id", owner_id)
        .eq("is_sample", False)
        .order("created_at", desc=True)
        .execute()
    )
    return [_row_to_vinyl(r) for r in res.data]


def get_marketplace_vinyls(current_user_id: str) -> List[Vinyl]:
    res = (
        _sb().table("vinyls")
        .select("*")
        .neq("owner_id", current_user_id)
        .order("created_at", desc=True)
        .execute()
    )
    return [_row_to_vinyl(r) for r in res.data]


def get_vinyl_by_id(vinyl_id: str) -> Optional[Vinyl]:
    res = _sb().table("vinyls").select("*").eq("id", vinyl_id).execute()
    return _row_to_vinyl(res.data[0]) if res.data else None


def save_vinyl(v: Vinyl) -> None:
    _sb().table("vinyls").upsert({
        "id":           v.id,
        "title":        v.title,
        "artist":       v.artist,
        "year":         v.year,
        "genre":        v.genre,
        "condition":    v.condition,
        "price":        v.price,
        "availability": v.availability,
        "image_path":   v.image_path,
        "description":  v.description,
        "owner_id":     v.owner_id,
        "owner_name":   v.owner_name,
        "created_at":   v.created_at,
        "is_sample":    v.is_sample,
    }).execute()


def delete_vinyl(vinyl_id: str) -> None:
    _sb().table("vinyls").delete().eq("id", vinyl_id).execute()


def copy_image(src_path: str) -> str:
    """
    Sube la imagen al bucket privado y devuelve el filename.
    El filename se guarda en vinyls.image_path y se convierte
    a signed URL en tiempo de lectura mediante _resolve_image().
    """
    ext       = os.path.splitext(src_path)[1].lower()
    file_name = f"{uuid.uuid4().hex}{ext}"
    mime      = mimetypes.guess_type(src_path)[0] or "application/octet-stream"

    with open(src_path, "rb") as f:
        data = f.read()

    _sb_storage().storage.from_(BUCKET).upload(
        path         = file_name,
        file         = data,
        file_options = {"contentType": mime, "upsert": "false"},
    )

    return file_name   # ← solo el nombre, no la URL


# ── Messages ──────────────────────────────────────────────────────────────────
def _row_to_msg(row: dict) -> Message:
    return Message(
        id            = row["id"],
        sender_id     = row["sender_id"],
        sender_name   = row["sender_name"],
        receiver_id   = row["receiver_id"],
        receiver_name = row["receiver_name"],
        content       = row["content"],
        vinyl_id      = row.get("vinyl_id"),
        vinyl_title   = row.get("vinyl_title"),
        timestamp     = row["timestamp"],
        is_read       = bool(row.get("is_read", False)),
    )


def get_conversations(user_id: str) -> List[Conversation]:
    res = (
        _sb().table("messages")
        .select("*")
        .or_(f"sender_id.eq.{user_id},receiver_id.eq.{user_id}")
        .order("timestamp", desc=False)
        .execute()
    )

    msgs = [_row_to_msg(r) for r in res.data]
    grouped: dict[str, List[Message]] = {}
    for m in msgs:
        other = m.receiver_id if m.sender_id == user_id else m.sender_id
        grouped.setdefault(other, []).append(m)

    convs = []
    for other_id, ms in grouped.items():
        last       = ms[-1]
        other_name = last.receiver_name if last.sender_id == user_id else last.sender_name
        convs.append(Conversation(
            other_user_id   = other_id,
            other_user_name = other_name,
            messages        = ms,
            vinyl_id        = last.vinyl_id,
            vinyl_title     = last.vinyl_title,
        ))
    convs.sort(
        key     = lambda c: c.last_message.timestamp if c.last_message else "",
        reverse = True,
    )
    return convs


def get_messages_with(user_id: str, other_id: str) -> List[Message]:
    res = (
        _sb().table("messages")
        .select("*")
        .or_(
            f"and(sender_id.eq.{user_id},receiver_id.eq.{other_id}),"
            f"and(sender_id.eq.{other_id},receiver_id.eq.{user_id})"
        )
        .order("timestamp", desc=False)
        .execute()
    )
    return [_row_to_msg(r) for r in res.data]


def save_message(m: Message) -> None:
    _sb().table("messages").upsert({
        "id":            m.id,
        "sender_id":     m.sender_id,
        "sender_name":   m.sender_name,
        "receiver_id":   m.receiver_id,
        "receiver_name": m.receiver_name,
        "content":       m.content,
        "vinyl_id":      m.vinyl_id,
        "vinyl_title":   m.vinyl_title,
        "timestamp":     m.timestamp,
        "is_read":       m.is_read,
    }).execute()


def mark_as_read(current_user_id: str, other_user_id: str) -> None:
    (
        _sb().table("messages")
        .update({"is_read": True})
        .eq("receiver_id", current_user_id)
        .eq("sender_id",   other_user_id)
        .execute()
    )


def unread_count(user_id: str) -> int:
    res = (
        _sb().table("messages")
        .select("id", count="exact")
        .eq("receiver_id", user_id)
        .eq("is_read",     False)
        .execute()
    )
    return res.count or 0


# ── Usuarios ─────────────────────────────────────────────────────────────────
def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def register_user(username: str, password: str) -> Tuple[bool, str]:
    """
    Registra un nuevo usuario.
    Retorna (True, user_id) si tuvo éxito, o (False, mensaje_error) si el
    nombre de usuario ya existe o hay otro error.
    """
    # Verificar si el username ya existe
    res = (
        _sb().table("users")
        .select("id")
        .eq("username", username)
        .execute()
    )
    if res.data:
        return False, "El nombre de usuario ya está en uso."

    user_id = uuid.uuid4().hex
    _sb().table("users").insert({
        "id":            user_id,
        "username":      username,
        "password_hash": _hash_password(password),
        "created_at":    datetime.now().isoformat(),
    }).execute()
    return True, user_id


def login_user(username: str, password: str) -> Optional[Tuple[str, str]]:
    """
    Valida credenciales. Retorna (user_id, username) si son correctas, None si no.
    """
    res = (
        _sb().table("users")
        .select("id, username, password_hash")
        .eq("username", username)
        .execute()
    )
    if not res.data:
        return None
    row = res.data[0]
    if row["password_hash"] != _hash_password(password):
        return None
    return row["id"], row["username"]


